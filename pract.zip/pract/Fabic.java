package K.pack;

public abstract class Fabic{

    public abstract void createfabicseries(int y);
}